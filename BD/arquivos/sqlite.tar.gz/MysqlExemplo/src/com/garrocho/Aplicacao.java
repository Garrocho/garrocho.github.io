package com.garrocho;

import java.util.Scanner;

public class Aplicacao {

	public static void main(String args[]) {

		BancoDadosCliente bdCliente = new BancoDadosCliente();
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Digite um ID: ");
			int id = scanner.nextInt();
			System.out.println("Digite um Nome: ");
			String nome = scanner.next();
			bdCliente.criaNovoBancoDados();
			bdCliente.iniciaConexao();
			//bdCliente.delCliente(20);
			
			if (bdCliente.addCliente(id, nome)) {
				System.out.println("Cliente " + nome + " adicionado com sucesso!");
			}
			else {
				System.out.println("Nao foi possivel adicionar o Cliente " + nome);
			}
			
			System.out.println("Listando Todos os Clientes: ");
			
			for (Cliente cli : bdCliente.getTodosClientes()) {
				System.out.println(cli.id);
				System.out.println(cli.nome);
			}
			
			bdCliente.fechaConexao();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
