package com.garrocho;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.garrocho.Cliente;

public class BancoDadosCliente extends BancoDados {
	private String SQL;
	private ResultSet resultado;

	public BancoDadosCliente() {
		super();
	}

	public int qtdeTotalClientes() {
		int resul = -1;
		try {
			iniciaConexao();
			SQL = "SELECT COUNT(*) AS qtde FROM cliente";
			resultado = executaComando(SQL);
			resul = resultado.getInt("qtde");
			fechaConexao();
			return resul;
		} catch (Exception e) {
			return resul;
		}
	}

	public ArrayList<Cliente> getTodosClientes() {
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		try {
			iniciaConexao();
			SQL = "SELECT * FROM cliente";
			resultado = executaComando(SQL);
			while (resultado.next()) {
				Cliente cliente = new Cliente();
				cliente.setId(resultado.getInt("id"));
				cliente.setNome(resultado.getString("nome"));
				clientes.add(cliente);
			}
			fechaConexao();
			return clientes;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}	
	
	public List<Cliente> getCliente(String nome) {
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		try {
			iniciaConexao();
			SQL = "SELECT * FROM cliente WHERE cliente.nome LIKE \'" + nome + "\'";
			resultado = executaComando(SQL);
			while (resultado.next()) {
				Cliente cliente = new Cliente();
				cliente.setId(resultado.getInt("id"));
				cliente.setNome(resultado.getString("nome"));
				clientes.add(cliente);
			}
			fechaConexao();
			return clientes;
		} catch (Exception e) {
			return null;
		}
	}	

	public boolean addCliente(int id, String nome) {
		try {
			iniciaConexao();
			SQL = "INSERT INTO cliente (id, nome) VALUES (" + id + ",'" + nome + "')";
			executaSemRetorno(SQL);
			fechaConexao();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	public Boolean delCliente(int id) {
		try {
			iniciaConexao();
			SQL = "DELETE FROM cliente WHERE cliente.id = " + id;
			executaSemRetorno(SQL);
			fechaConexao();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void updateCliente(int id, String nome) throws SQLException, ClassNotFoundException {
		SQL = "UPDATE cliente SET nome = '" + nome + "' WHERE cliente.id = " + id + "";
		executaSemRetorno(SQL);
	}
}