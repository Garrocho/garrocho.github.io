#!/usr/bin/env python
import logging
from scapy.all import *
from termcolor import colored, cprint
import argparse
import datetime
import sys

mac_list = []
interface = "mon0"

def imprimirPontoAcesso(mac, ssid):
    print colored("* Encontrado * ", "red", \
     attrs=["bold"]) + "%s" % (mac), \
     colored("Ponto de Acesso", "yellow", \
     attrs=["bold"]), "do SSID:", \
     colored(ssid, "green", attrs=["bold"])

def imprimirCliente(mac, ssid):
    print colored("* Encontrado * ", "red", \
     attrs=["bold"]) + "%s" % (mac), \
     colored("Cliente", "yellow", \
     attrs=["bold"]), "do SSID:", \
     colored(ssid, "green", attrs=["bold"])

def analisadorPacote(pacote):

    if pacote.haslayer(Dot11):
        if pacote.type == 0 and pacote.subtype == 8:
            if pacote.addr2 not in mac_list:
                mac_list.append(pacote.addr2)
                imprimirPontoAcesso(pacote.addr2, pacote.info)

        if pacote.haslayer(Dot11ProbeReq):
            if pacote.addr2 not in mac_list:
                mac_list.append(pacote.addr2)
                if pacote.info != "":
                    imprimirCliente(pacote.addr2, pacote.info)

sniff(iface=interface, prn=analisadorPacote, store=0)
