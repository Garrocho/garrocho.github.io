#!/usr/bin/python
# -*- coding: utf-8 -*-
import pyPdf
import optparse
from pyPdf import PdfFileReader


def imprimir_meta(arquivo):
    arq_pdf = PdfFileReader(file(arquivo, 'rb'))
    info_doc = arq_pdf.getDocumentInfo()
    print '[*] PDF MetaData para: ' + str(arquivo)
    for item_meta in info_doc:
        print '[+] ' + item_meta + ':' + info_doc[item_meta]


def main():
    analisador = optparse.OptionParser("use %prog "+\
      "-F <arquivo PDF>")
    analisador.add_option('-F', dest='arquivo',\
        type='string', help='especifique o arquivo PDF')

    (opcoes, args) = analisador.parse_args()
    arquivo = opcoes.arquivo
    if arquivo == None:
        print analisador.usage
        exit(0)
    else:
        imprimir_meta(arquivo)


if __name__ == '__main__':
    main()
