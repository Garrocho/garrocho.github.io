#!/usr/bin/python
# -*- coding: utf-8 -*-
import zipfile
import optparse
from threading import Thread


def extrairArquivo(arquivo, senha):
    try:
        arquivo.extractall(pwd=senha)
        print '[+] Senha encontrada: ' + senha + '\n'
    except:
        pass


def inicio():
    analisador = optparse.OptionParser("use %prog "+\
      "-f <arquivozip> -d <dicionario>")
    analisador.add_option('-f', dest='nomezip', type='string',\
      help='especifique o arquivo zip')
    analisador.add_option('-d', dest='nomedic', type='string',\
      help='especifique o arquivo dicionario')
    (opcoes, argumentos) = analisador.parse_args()
    if (opcoes.nomezip == None) | (opcoes.nomedic == None):
        print analisador.usage
        exit(0)
    else:
        nomezip = opcoes.nomezip
        nomedic = opcoes.nomedic

    ArquivoZipe = zipfile.ZipFile(nomezip)
    arquivoDici = open(nomedic)

    for linha in arquivoDici.readlines():
        senha = linha.strip('\n')
        t = Thread(target=extrairArquivo, args=(ArquivoZipe, senha))
        t.start()


if __name__ == '__main__':
    inicio()
