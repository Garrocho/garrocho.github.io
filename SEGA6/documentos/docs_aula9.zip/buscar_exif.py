#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib2
import optparse
from urlparse import urlsplit
from os.path import basename
from bs4 import BeautifulSoup
from PIL import Image
from PIL.ExifTags import TAGS


def buscarImagens(url):
    print '[+] Buscando imagens em ' + url
    conteudoURL = urllib2.urlopen(url).read()
    soup = BeautifulSoup(conteudoURL)
    imgTags = soup.findAll('img')
    return imgTags


def baixarImagem(imgTag):
    try:
        fonteIMG = imgTag['src']
        print '[+] Baixando imagem ', urlsplit(fonteIMG)[2]
        conteudoIMG = urllib2.urlopen(fonteIMG).read()
        nomeArqIMG = basename(urlsplit(fonteIMG)[2])
        arqIMG = open(nomeArqIMG, 'wb')
        arqIMG.write(conteudoIMG)
        arqIMG.close()
        return nomeArqIMG
    except:
        return None


def testeParaExif(nomeArqIMG):
    try:
        dadosExif = {}
        arqIMG = Image.open(nomeArqIMG)
        info = arqIMG._getexif()
        if info:
            for (tag, valor) in info.items():
                decoded = TAGS.get(tag, tag)
                dadosExif[decoded] = valor
            exifGPS = dadosExif['GPSInfo']
            print dadosExif
            if exifGPS:
                print '[*] ' + nomeArqIMG + \
                 ' contem GPS MetaData'
    except:
        pass


def inicio():
    analisador = optparse.OptionParser('use %prog "+\
      "-u <url alvo>')
    analisador.add_option('-u', dest='url', type='string',
      help='especifique o endereco url')

    (opcoes, args) = analisador.parse_args()
    url = opcoes.url
    if url == None:
        print analisador.usage
        exit(0)
    else:
        imgTags = buscarImagens(url)
        for imgTag in imgTags:
            nomeArqIMG = baixarImagem(imgTag)
            if nomeArqIMG is not None:
                testeParaExif(nomeArqIMG)


if __name__ == '__main__':
    inicio()
