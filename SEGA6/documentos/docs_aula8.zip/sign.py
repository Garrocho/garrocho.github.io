import os
from OpenSSL import crypto
from Crypto.PublicKey import RSA 
from Crypto.Signature import PKCS1_v1_5 
from Crypto.Hash import SHA256

def assinar(private_key_loc, data):
    rsakey = RSA.importKey(private_key_loc) 
    signer = PKCS1_v1_5.new(rsakey) 
    digest = SHA256.new() 
    digest.update(data)
    sign = signer.sign(digest) 
    return sign

def verificar(public_key_loc, signature, data):
    rsakey = RSA.importKey(public_key_loc) 
    signer = PKCS1_v1_5.new(rsakey) 
    digest = SHA256.new() 
    digest.update(data) 
    if signer.verify(digest, signature):
        return True
    return False

def verifica_chave(siape):
    if not os.path.exists("chaves/" + siape):
        print "Gerando Chave Privada: " + siape
        k = crypto.PKey()
        k.generate_key(crypto.TYPE_RSA, 1024)
        chave = crypto.dump_privatekey(crypto.FILETYPE_PEM, k)
        arquivo = open("chaves/" + siape, "w")
        arquivo.write(chave)
        arquivo.close()
        return chave
    else:
        arquivo = open("chaves/" + siape, "r")
        chave = arquivo.read()
        arquivo.close()
        return chave

if __name__ == '__main__':
    chave = verifica_chave("1146652")
    print "Assinando o Documento"
    assinatura = assinar(chave, "Olo Mundo Aonde")
    print "Verficicando Assinatura"
    print verificar(chave, assinatura, "Ola Mundo Aonde")