#!/usr/bin/python
# -*- coding: utf-8 -*-
import pyPdf
import optparse
from pyPdf import PdfFileReader
import os, glob

def imprimir_meta(arquivo, autor, guarda):
    try:
        arq_pdf = PdfFileReader(file(arquivo, 'rb'))
        info_doc = arq_pdf.getDocumentInfo()
        print '[*] PDF MetaData para: ' + str(arquivo)
        for item_meta in info_doc:
            if item_meta == '/Author':
                if autor in info_doc[item_meta]:
                    guarda.write(str(arquivo)+'\n')
                    return 1
                else:
                    return 0

    except Exception as e:
        print e

def pega_pdf(pasta, autor):
    print autor
    guarda = open('autor.txt', 'w')
    guarda.write('Autor: '+autor+'\n')

    os.chdir(pasta)

    for arquivo in glob.glob('*'):
        retorno = imprimir_meta(arquivo, autor, guarda)

def main():
    analisador = optparse.OptionParser("use %prog "+\
      "-a <arquivo PDF> -p <pasta>")
    analisador.add_option('-a', dest='autor',\
        type='string', help='especifique o nome do autor')
    analisador.add_option('-p', dest='pasta',\
        type='string', help='especifique a pasta')

    (opcoes, args) = analisador.parse_args()

    autor = opcoes.autor
    pasta = opcoes.pasta

    if (autor == None) | (pasta == None):
        print analisador.usage
        exit(0)
    else:
        pega_pdf(pasta, autor)


if __name__ == '__main__':
    main()
