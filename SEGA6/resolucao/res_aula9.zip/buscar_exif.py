#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib2
import optparse
from urlparse import urlsplit
from os.path import basename
import os
from bs4 import BeautifulSoup
from PIL import Image
from PIL.ExifTags import TAGS
import shutil


def buscarImagens(url):
    print '[+] Buscando imagens em ' + url
    conteudoURL = urllib2.urlopen(url).read()
# TINHA UM WARNNING AQUI, POR CONTA DA NÃO ESPECIFFICAÇÃO DO TIPO DE VERIFICACAO DA URL
    soup = BeautifulSoup(conteudoURL, "html.parser")
    imgTags = soup.findAll('img')
    return imgTags


def baixarImagem(imgTag):
    try:
        fonteIMG = imgTag['src']
        print '[+] Baixando imagem ', urlsplit(fonteIMG)[2]
        conteudoIMG = urllib2.urlopen(fonteIMG).read()
        nomeArqIMG = basename(urlsplit(fonteIMG)[2])
# BAIXANDO O ARQUIVO DE IMAGEM PARA A PASTA TEMPORÁRIA
        arqIMG = open("tmp/"+nomeArqIMG, 'wb')
        arqIMG.write(conteudoIMG)
        arqIMG.close()
        return nomeArqIMG
    except:
        return None


def testeParaExif(nomeArqIMG):
    try:
        dadosExif = {}
        arqIMG = Image.open("tmp/"+nomeArqIMG)
        info = arqIMG._getexif()
        if info:
            for (tag, valor) in info.items():
                decoded = TAGS.get(tag, tag)
                dadosExif[decoded] = valor
            exifGPS = dadosExif['GPSInfo']
            # print exifGPS
            if exifGPS:
# SE POSSUIR DADOS DE GPS NA IMAGEM CRIA UM ARQUIVO DE TEXTO DOS DADOS
# E MOVE O ARQUIVO DE IMAGEM DO DIR. TMP PARA GPSINFO
                print '[*] ' + nomeArqIMG + \
                 ' contem GPS MetaData'
                nomeSimples = nomeArqIMG.split('.')
                arqTxt = open('gpsInfo/'+nomeSimples[0] + '.txt', 'w')
                arqTxt.write(str(dadosExif['GPSInfo']))
                arqTxt.close()
                shutil.move('tmp/'+nomeArqIMG, "gpsInfo")
    except:
        pass


def inicio():
    analisador = optparse.OptionParser('use %prog "+\
      "-u <url alvo>')
    analisador.add_option('-u', dest='url', type='string',
      help='especifique o endereco url')

# CRIA O DIRETÓRIO PARA RECEBER AS IMAGENS QUE SERÃO ANALISADAS
    try:
        os.mkdir('tmp')
    except:
        pass

# CRIA O DIRETÓRIO QUE RECEBERÁ OS DADOS EXIF + O ARQUIVO DE IMAGEM
    try:
        os.mkdir('gpsInfo')
    except:
        pass

    (opcoes, args) = analisador.parse_args()
    url = opcoes.url
    if url == None:
        print analisador.usage
        exit(0)
    else:
        imgTags = buscarImagens(url)
        for imgTag in imgTags:
            nomeArqIMG = baixarImagem(imgTag)
            if nomeArqIMG is not None:
                testeParaExif(nomeArqIMG)
# APAGA AS IMAGENS BAIXADAS PARA VERIFICAÇÃO DE SEU EXIF
    shutil.rmtree('tmp')


if __name__ == '__main__':
    inicio()
