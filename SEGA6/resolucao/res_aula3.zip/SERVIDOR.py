import socket
from threading import Thread
import json

mensagens = []

def trata_cliente(soquete, cliente):
    global mensagens
    solicitacao = soquete.recv(1024)
    vetor = solicitacao.split('(99:99)')
    print cliente, vetor
    if vetor[0] == 'ENVIAR':
        mensagens.append(vetor[1])
    elif vetor[0] == 'LISTAR':
        soquete.send(json.dumps(mensagens))
    soquete.close()

host = '127.0.0.1'    # Endereco IP do Servidor
porta = 9100          # Porta que o Servidor esta
soquete = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
origem = (host, porta)
soquete.bind(origem)
soquete.listen(0)
while True:
    Thread(target=trata_cliente,args=(soquete.accept())).start()
