import socket
import time
import json
from threading import Thread

host = '127.0.0.1'     # Endereco IP do Servidor
porta = 9100           # Porta que o Servidor esta
destino = (host, porta)
msg = ""
a_msgs = []

def enviar():
	global msg
	global a_msgs 
	msg = raw_input("")
	while msg != 'sair':
		soquete = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		soquete.connect(destino)
		soquete.send('ENVIAR(99:99)'+msg)
		a_msgs.append(msg)
		soquete.close()
		msg = raw_input("")

def receber():
	global msg
	global a_msgs
	while msg != 'sair':
		time.sleep(2)
		soquete = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		soquete.connect(destino)
		soquete.send('LISTAR')
		n_msgs = json.loads(soquete.recv(1024))
		if len(a_msgs) < len(n_msgs):
			n = n_msgs[len(a_msgs):]
			a_msgs = n_msgs
			for i in n:
				print i

Thread(target=receber).start()
Thread(target=enviar).start()
