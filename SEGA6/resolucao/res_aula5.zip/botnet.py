from pexpect import pxssh
import optparse
import time
from threading import *

class Cliente:
    def __init__(self, usuario, senha, host_rn):
        self.usuario = usuario
        self.senha = senha
        self.host = host_rn
        self.ssh = self.ssh_conecta()

    def ssh_conecta(self):
        s = pxssh.pxssh()
        if s.login(self.host, self.usuario, self.senha):
            print "Conectado"
            return s
        else:
            print "Nao conectado"

    def executa_comando(self, comando):
        self.ssh.sendline(comando)
        self.ssh.prompt()
        return self.ssh.before


def inicio():
    comando = raw_input("Comando: ")
    clientes = []

    arquivo = open('dados.txt', 'r')

    total = []

    for line in arquivo:
        linha = line.strip('\n\r')
        cliente = linha.split(',')
        classe = Cliente(cliente[0], cliente[1], cliente[2])
        total.append(classe)

    for acesso in total:
        retorno = acesso.executa_comando(comando)
        print "Resposta "+acesso.host+" = "+retorno

if __name__ == '__main__':
    inicio()
