#!/usr/bin/python
# -*- coding: utf-8 -*-
import optparse
import threading
from socket import *
from threading import *
import thread

# t1 = thread.allocate_lock()
# pool_sema = BoundedSemaphore()
pool_sema = Lock()

def conexaoScan(host, porta):
    pool_sema.acquire()
    try:
        soquete = socket(AF_INET, SOCK_STREAM)
        soquete.connect((host, porta))
        soquete.send('Segurança da Informação\r\n')
        resultados = soquete.recv(100)

        try:

            resultados_separados = resultados.split('Server: ')
            resultados_separados_server = resultados_separados[1].split( )

        except:
            print 'Nenhuma informação relevante'

        #print '[+] %d/tcp aberta' % porta

        if resultados_separados_server[0] in open('Acunetix.html').read():
            print('Vulnerabilidade encontrada')
        else:
            print('Vulnerabilidade não encontrada')

    except:
        #print '[-] %d/tcp fechada' % porta
        pass
    finally:
        pool_sema.release()
        soquete.close()

def portaScan(host, portas):
    try:
        IPSite = gethostbyname(host)
    except:
        print "[-] Nao conseguiu resolver o host '%s'" % host
        return

    try:
        nomeSite = gethostbyaddr(IPSite)
        print '\n[+] Resultados para: ' + nomeSite[0]
    except:
        print '\n[+] Resultados para: ' + IPSite

    inicio = portas[0]
    fim = portas[1]

    lista_portas = range(int(inicio), int(fim))

    setdefaulttimeout(1)
    for porta in lista_portas:
        t = Thread(target=conexaoScan,args=(host,int(porta)))
        t.start()

def inicio():
    analisador = optparse.OptionParser('use explorador_portas '+\
      '-H <host alvo> -p <porta(s) alvo>')
    analisador.add_option('-H', dest='host', type='string',\
      help='especifique o host alvo')
    analisador.add_option('-p', dest='porta', type='string',\
      help='especifique a porta[s] alvo separadas por virgula')

    (opcoes, args) = analisador.parse_args()

    host = opcoes.host
    porta = str(opcoes.porta).split(',')

    if (host == None) | (porta[0] == None):
        print analisador.usage
        exit(0)

    portaScan(host, porta)


if __name__ == '__main__':
    inicio()
