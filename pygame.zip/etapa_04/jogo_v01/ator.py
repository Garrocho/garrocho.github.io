import pygame


class Ator(pygame.sprite.Sprite):
    """ Classe Ator """

    def __init__(self, pos_x=0, pos_y=0):
        """ Construtor:  __init__()) -> instancia de ator """
        pygame.sprite.Sprite.__init__(self)
        self.poses = []
        self.__pt_pose = 0 # ponteiro para pose atual.
        self.__pos_x = pos_x
        self.__pos_y = pos_y


    def inserir_pose(self, nome_arq_img):
        """ Armazena uma 'surface' dentro da lista poses """
        self.poses.append(pygame.image.load(nome_arq_img))
        self.image = self.poses[self.__pt_pose]
        self.rect = self.image.get_rect()
        self.rect.x = self.__pos_x
        self.rect.y = self.__pos_y


    def update(self):
        """ Reimplementa updade() """
        if self.__pt_pose == len(self.poses): self.__pt_pose = 0
        self.image = self.poses[self.__pt_pose]
        self.__pt_pose += 1
