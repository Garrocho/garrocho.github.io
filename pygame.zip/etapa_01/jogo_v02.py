import pygame

pygame.init()
tela = pygame.display.set_mode((800, 600)) # tela eh uma 'surface'
paola = pygame.image.load("paola.png") # paola eh uma 'surface'
tela.blit(paola, (0, 100))
print "Ctrl+C para encerrar ;-)"
while (True):
    pygame.display.update()
pygame.display.quit()
