import time
import socket
import threading

def trata_cliente(conexao, cliente):
	print 'Concetado por', cliente
	mensagem = conexao.recv(1024)
	time.sleep(2)
	print "Cliente ", cliente[0], "Recebida: ", mensagem
	conexao.close()


host = '127.0.0.1' # Endereco IP do Servidor
porta = 5000       # Porta que o Servidor esta
soquete = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
origem = (host, porta)
soquete.bind(origem)
soquete.listen(0)
while True:
	tc = threading.Thread(target=trata_cliente, args=soquete.accept())
	tc.start()