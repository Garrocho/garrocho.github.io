import socket

PORTA = 2222

servidor = socket.socket()
servidor.bind(("", PORTA))
servidor.listen(5)
print("Servidor escutando na porta: ", PORTA)

while True:
	cliente, endereco = servidor.accept()
	print("Conexao aceita de: ", endereco)
	mensagem = "Ola! No que posso te ajudar?"
	cliente.send(mensagem.encode())
	cliente.close()
