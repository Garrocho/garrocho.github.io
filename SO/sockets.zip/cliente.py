import socket

cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
cliente.connect(("127.0.0.1", 2222))
mensagem = cliente.recv(1024)
print("Mensagem recebida: ", mensagem.decode())
cliente.close()
